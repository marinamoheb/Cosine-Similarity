package com.company;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Main<map> {


    public static void main(String[] args) throws IOException {
        Cosine_Similarity cs = new Cosine_Similarity();
        LinkedHashMap<String, Double> map = new LinkedHashMap<String, Double>();
        String text1, text2;
        double result;
        //D1,D2
        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/100.txt")).stream().collect(Collectors.joining(" "));
        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/101.txt")).stream().collect(Collectors.joining(" "));
        result = cs.Cosine_Similarity_Score(text1, text2);
        map.put("D1 and D2 cosine similarity", result);
//        System.out.println("D1 and D2 cosine similarity "+ result);

        //D1,D3
        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/100.txt")).stream().collect(Collectors.joining(" "));
        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/102.txt")).stream().collect(Collectors.joining(" "));
        result = cs.Cosine_Similarity_Score(text1, text2);
        map.put("D1 and D3 cosine similarity", result);
//        System.out.println("D1 and D3 cosine similarity "+ result);

        //D1,D4
        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/100.txt")).stream().collect(Collectors.joining(" "));
        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/103.txt")).stream().collect(Collectors.joining(" "));
        result = cs.Cosine_Similarity_Score(text1, text2);
        map.put("D1 and D4 cosine similarity", result);
//        System.out.println("D1 and D4 cosine similarity "+ result);

        //D2,D3
        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/101.txt")).stream().collect(Collectors.joining(" "));
        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/102.txt")).stream().collect(Collectors.joining(" "));
        result = cs.Cosine_Similarity_Score(text1, text2);
        map.put("D2 and D3 cosine similarity", result);
//        System.out.println("D2 and D3 cosine similarity "+ result);

        //D2,D4
        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/101.txt")).stream().collect(Collectors.joining(" "));
        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/105.txt")).stream().collect(Collectors.joining(" "));
        result = cs.Cosine_Similarity_Score(text1, text2);
        map.put("D2 and D4 cosine similarity", result);
//        System.out.println("D2 and D4 cosine similarity "+ result);

        //D3,D4
        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/102.txt")).stream().collect(Collectors.joining(" "));
        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/105.txt/")).stream().collect(Collectors.joining(" "));
        result = cs.Cosine_Similarity_Score(text1, text2);
        map.put("D3 and D4 cosine similarity", result);
//        System.out.println("D3 and D4 cosine similarity "+ result);
//        //D3,D4
//        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/105.txt")).stream().collect(Collectors.joining(" "));
//        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/109.txt/")).stream().collect(Collectors.joining(" "));
//        result = cs.Cosine_Similarity_Score(text1, text2);
//        map.put("D4 and D10 cosine similarity", result);
////        System.out.println("D3 and D4 cosine similarity "+ result);
//        //D3,D4
//        text1 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/102.txt")).stream().collect(Collectors.joining(" "));
//        text2 = Files.readAllLines(Paths.get("C:/Users/user/Downloads/docs/108.txt/")).stream().collect(Collectors.joining(" "));
//        result = cs.Cosine_Similarity_Score(text1, text2);
//        map.put("D3 and D9 cosine similarity", result);
////        System.out.println("D3 and D4 cosine similarity "+ result);
        map.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .forEach(System.out::println);
    }

}



